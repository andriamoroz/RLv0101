

/* Includes ------------------------------------------------------------------*/
#include <stm32f10x_rtc.h>
#include "main.h"
#include "Board.h"
#include "system.h"

uint32_t RTC_GetMyCounter(RTC_DateTime_t* DateTime);

extern CommPLC_t CommPLC;
extern PcbUnit_t PCB_Conf[NMB_UNIT];
extern MBComm_t *pMBComm;
extern osSemaphoreId CommRcv_Sem;
extern USHORT usSRegHoldBuf[S_REG_HOLDING_NREGS_BUFF_BUFF];
extern UnitSeting_t UnitSeting;
extern UnitSeting_t *pUnitSeting;
extern PcbSeting_t *pPcbSeting;
extern const uint16_t FwVersion[3];
extern RTC_DateTime_t DateTime;
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

static err_t PLC_CommComplite(void) {
 uint8_t i;

	 for(i = 0; i < 20; i++)
	 {
		 if (CommPLC.State.b.Complete) {
			 return ERR_OK;
		 }
		 vTaskDelay(10);
	 }
	 return ERR_TIMEOUT;
}

void MbComm_thread(void *pvParameters) {
 u32 Offset;
 uint8_t i, k;

	 while(1)
	 {
 		 osSemaphoreWait(CommRcv_Sem, osWaitForever);
 		 if (pMBComm->dw.SetCmd) {
 			 pMBComm->dw.SetCmd = 0;
 			 if (pMBComm->dw.Command == GET_VERSION) {
 				 memcpy(&usSRegHoldBuf[S_REG_HOLDING_START_BUFF_BUFF], FwVersion, sizeof(FwVersion));
 			 } else if (pMBComm->dw.Command == GET_RTU_UNIT_CONF) {
 				 memcpy(pUnitSeting, &UnitSeting, sizeof(UnitSeting_t));
 			 } else if (pMBComm->dw.Command == SET_RTU_UNIT_CONF) {
 				 memcpy(&UnitSeting, pUnitSeting, sizeof(UnitSeting_t));
 				 UnitSeting.wCRC = CRC16((uint8_t*)&UnitSeting, sizeof(UnitSeting_t)-2);
// 				 sEEPROM_WriteBuffer((uint8_t*)&UnitSeting, OFFSET_UNITSETING, sizeof(UnitSeting_t));
 				 NVIC_SystemReset();
 			 } else if (pMBComm->dw.Command == INT_PLC_INP_GET) {
 				 if (pMBComm->dw.NmbPCB >= NMB_UNIT) {
 					 continue;
 				 }
 				 PLC_CommComplite();
 				 if (CommPLC.State.b.Complete == 0) {
 					 continue;
 				 }
 				 CommPLC.Comm = pMBComm->dw.PlcComm;
 				 CommPLC.State.b.NmbUnit = pMBComm->dw.NmbPCB;
 				 CommPLC.State.b.Execution = 1;
 				 CommPLC.State.b.Complete = 0;
 				 PLC_CommComplite();
 				 if (CommPLC.State.b.Complete == 0) {
 					 CommPLC.State.b.Complete = 1;
 					 CommPLC.State.b.Execution = 0;
 					 CommPLC.Comm = PLC_NO_COMM;
// 	 				 if (pMBComm->dw.PlcComm == PLC_GET_CURR_ADC) {
// 	 					 memcpy(&usSRegHoldBuf[S_REG_HOLDING_START_BUFF_BUFF], &CommPLC.Data, NMB_ADC);
// 	 				 }
 					 continue;
 				 }
/* 				 if (pMBComm->dw.PlcComm == PLC_GET_CURR_ADC) {
 					 memcpy(&usSRegHoldBuf[S_REG_HOLDING_START_BUFF_BUFF], &CommPLC.Data, NMB_ADC);
 				 } else {
 					 memcpy(&usSRegHoldBuf[S_REG_HOLDING_START_BUFF_BUFF], &CommPLC.Data, NMB_ADC*4);
 				 }*/
 			 } else if (pMBComm->dw.Command == GET_PCB_CONF) {
 				 if (pMBComm->dw.NmbPCB >= NMB_UNIT) {
 					 continue;
 				 }
// 				 Offset = OFFSET_PCBSETING + pMBComm->dw.NmbPCB * PAGE_SIZE;
// 				 sEEPROM_ReadBuffer((uint8_t*)pPcbSeting, Offset, sizeof(PcbSeting_t));
 			 } else if (pMBComm->dw.Command == SET_PCB_CONF) {
 				 if (pMBComm->dw.NmbPCB >= NMB_UNIT) {
 					 continue;
 				 }
// 				 Offset = OFFSET_PCBSETING + pMBComm->dw.NmbPCB * PAGE_SIZE;
 				 pPcbSeting->bCRC = CRC8((uint8_t*)pPcbSeting, sizeof(PcbSeting_t)-1);
// 				 sEEPROM_WriteBuffer((uint8_t*)pPcbSeting, Offset, sizeof(PcbSeting_t));
 				 k = 0;
 				 for (i = 0; i < NMB_ADC; i++)
 				 {
 					 CommPLC.Data[k] = pPcbSeting->eInpOn[i];
 					 CommPLC.Data[k+1] = pPcbSeting->eInpOff[i];
 					 CommPLC.Data[k+2] = pPcbSeting->eInpShort[i];
 					 CommPLC.Data[k+3] = pPcbSeting->eInpBreak[i];
 					 k += 4;
 				 }
 				 PCB_Conf[pMBComm->dw.NmbPCB].Conf.b.InpActive = pPcbSeting->Conf.b.InpActive;
 				 PCB_Conf[pMBComm->dw.NmbPCB].Conf.b.OutpActive = pPcbSeting->Conf.b.OutpActive;
 				 PCB_Conf[pMBComm->dw.NmbPCB].InpAddr = pPcbSeting->InpAddr;
 				 PCB_Conf[pMBComm->dw.NmbPCB].OutpAddr = pPcbSeting->OutpAddr;
 				 CommPLC.State.b.NmbUnit = pMBComm->dw.NmbPCB;
// 				 CommPLC.Comm = PLC_SET_SETING;
 				 CommPLC.State.b.Execution = 1;
 				 CommPLC.State.b.Complete = 0;
 				 PLC_CommComplite();
 				 if (CommPLC.State.b.Complete == 0) {
 					 CommPLC.State.b.Complete = 1;
 					 CommPLC.State.b.Execution = 0;
 					 CommPLC.Comm = PLC_NO_COMM;
 					 PCB_Conf[pMBComm->dw.NmbPCB].Conf.b.InpActive = 0;
 					 PCB_Conf[pMBComm->dw.NmbPCB].Conf.b.OutpActive = 0;
 				 }
 			 } else if (pMBComm->dw.Command == GET_SYSTEM_TIME) {
 				 i = DateTime.Year;
 				 Offset = (uint32_t)i << 26;
 				 i = DateTime.Month;
 				 Offset |= (uint32_t)i << 22;
 				 i = DateTime.Date;
 				 Offset |= (uint32_t)i << 17;
 				 i = DateTime.Hours;
 				 Offset |= (uint32_t)i << 12;
 				 i = DateTime.Minutes;
 				 Offset |= (uint32_t)i << 6;
 				 i = DateTime.Seconds;
 				 Offset |= (uint32_t)i;
 				 memcpy(&usSRegHoldBuf[S_REG_HOLDING_START_BUFF_BUFF], &Offset, sizeof(Offset));
 			 } else if (pMBComm->dw.Command == SET_SYSTEM_TIME) {
 				 memcpy(&Offset, &usSRegHoldBuf[S_REG_HOLDING_START_BUFF_BUFF], sizeof(Offset));
 				 DateTime.Year = Offset >> 26;
 				 DateTime.Month = (Offset >> 22) & 0x0f;
 				 DateTime.Date = (Offset >> 17) & 0x1f;
 				 DateTime.Hours = (Offset >> 12) & 0x1f;
 				 DateTime.Minutes = (Offset >> 6) & 0x3f;
 				 DateTime.Seconds = Offset & 0x3f;
 				 RTC_SetCounter(RTC_GetMyCounter(&DateTime));
 			 }
 		 }
	 }
}
