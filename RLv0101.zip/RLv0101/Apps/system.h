#ifndef __SYSTEM__H__
#define __SYSTEM__H__

#include <stm32f10x.h>
#include "port.h"
#include "mbport.h"
#include "Board.h"

#define OutLEN			30
#define InLEN			142

#define   _X_num      128  	/* X0-X64 		*/
#define   _Y_num      128   /* Y0-Y128 		*/
#define   _M_num      256   /* M0-M255 		*/
#define   _S_num      256   /* S0-S255 		*/
#define   _T_num      32    /* T0-T31 		*/
#define   _C_num      32    /* C0-C31 		*/
#define   _M8xxx_num  24    /* M8000-M8023 	*/
#define   _D_num      32    /* D0-D31 		*/
#define   _D8xxx_num  32    /* D8000-D8031 	*/

#define   _X_BYTE     ((_X_num + 7) / 8)
//#define   _X_BYTE_A	  ((_X_BYTE) * 2)
#define   _Y_BYTE     ((_Y_num + 7) / 8)
#define   _M_BYTE     ((_M_num + 7) / 8)
#define   _S_BYTE     ((_S_num + 7) / 8)
#define   _T_BYTE     ((_T_num + 7) / 8)
#define   _C_BYTE     ((_C_num + 7) / 8)
#define   _M8xxx_BYTE ((_M8xxx_num + 7)/8)

typedef void (*FunkList)(void);

typedef union {
  uint16_t d16;
  struct {
	  uint16_t Reserve			:10;
	  uint16_t StartDownTimer		:1;
	  uint16_t MonitoringOn		:1;
	  uint16_t FlashWriteState	:1;
	  uint16_t CodeError		:1;
	  uint16_t Run				:1;
	  uint16_t REN				:1;
  } w;
} PSW_t;

typedef union {
  uint16_t d16;
  struct {
	  uint16_t Reserve			:13;
//	  uint16_t CntInpErr		: 1;
	  uint16_t InpError	:1;
	  uint16_t MasterMode	:1;
	  uint16_t WriteUnitSeting	:1;
  } w;
} SysPSW_t;

typedef union {
	uint8_t d8;
	struct {
		uint8_t AdcReady	: 1;
		uint8_t Reserve			: 7;
	} b;
} TinyPSB_t;

typedef struct {
	uint8_t BIT0: 1;
	uint8_t BIT1: 1;
	uint8_t BIT2: 1;
	uint8_t BIT3: 1;
	uint8_t BIT4: 1;
	uint8_t BIT5: 1;
	uint8_t BIT6: 1;
	uint8_t BIT7: 1;
}TYPE_BIT;

typedef union {
  TYPE_BIT BIT;
  uint8_t  BYTE;
}TYPE_BIT_BYTE;

typedef union {
  struct {
	  uint8_t BYTEL;
	  uint8_t BYTEH;
  } BYTES;
  uint16_t  WORD;
}TYPE_BYTES_WORD;

typedef union {
  struct {
	  uint8_t Byte1;
	  uint8_t Byte2;
	  uint8_t Byte3;
	  uint8_t Byte4;
  } b;
  uint32_t  DWORD;
} TypeBytesDWORD_t;

#define FLASH_SECTOR_SIZE		1024
#define SHIFT_FLASH_SECTOR_SIZE	10
#define NMB_SECTOR_SIZE		16

#define PLCTypeArrayLen		8		//(PLCTypeArrayLenMAX-1)
#define PLCTypeArrayLenMAX	20

#endif


