

/* Includes ------------------------------------------------------------------*/
#include <stm32f10x_can.h>
#include "main.h"
#include "system.h"
#include "EEPROM_Base.h"

void RelayOn(uint8_t Rl);
void RelayOff(uint8_t Rl);

extern PSW_t PSW;
extern SysPSW_t *SysPSW;
extern osSemaphoreId PLC_Semph;
extern osSemaphoreId CanRxSmph;
extern USHORT usMRegInputBuf[M_REG_INPUT_NREGS];
extern UnitSeting_t UnitSeting;
extern PcbSeting_t PcbSeting;
extern CanRxMsg RxMessage;
extern CanTxMsg TxMessage;
extern uint32_t OwnAddrCan;
extern TYPE_BIT_BYTE rX[_X_BYTE];
extern TYPE_BIT_BYTE rY[_Y_BYTE], rYw[_Y_BYTE], rYi[_Y_BYTE];
extern TYPE_BIT_BYTE rS[_S_BYTE];
extern TYPE_BIT_BYTE *ErrX;
extern int16_t _D[_D_num];
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
uint8_t PCA9554_Buff[40];
uint8_t CAN_Buff[40];
PcbUnit_t PCB_Conf[NMB_UNIT];
PCB_Wrk_t PCB_Wrk;
CommPLC_t CommPLC;
TinyPSB_t TinyPSB;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/**
  * @brief  http server thread
  * @param arg: pointer on argument(not used here)
  * @retval None
  */
void OwnRelay(uint8_t rY) {
 uint8_t i;
 uint8_t btVar;

	 for (i = 0; i < NMB_RELAYS; i++)
	 {
		 btVar = rY & ((uint8_t)0x01 << i);
		 if (btVar) {
			 RelayOn(i);
		 } else {
			 RelayOff(i);
		 }
	 }
}
#ifndef DEBUG_PLC
/*
 *
 */
static void IWDG_activate(uint16_t num_of_ms) {
 uint8_t prescale_reg;
 uint8_t prescale_val;

    if (num_of_ms < 1) {
        num_of_ms = 1;
        prescale_reg = IWDG_Prescaler_32;
        prescale_val = 1;
    } else if (num_of_ms <= 4096) {
        prescale_reg = IWDG_Prescaler_32;
        prescale_val = 1;
    } else if (num_of_ms <= 8192) {
        prescale_reg = IWDG_Prescaler_64;
        prescale_val = 2;
    } else if (num_of_ms <= 16384) {
        prescale_reg = IWDG_Prescaler_128;
        prescale_val = 4;
    } else if (num_of_ms <= 32768) {
        prescale_reg = IWDG_Prescaler_256;
        prescale_val = 8;
    } else {
        num_of_ms = 32768;
        prescale_reg = IWDG_Prescaler_256;
        prescale_val = 8;
    }
    IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
    while (IWDG_GetFlagStatus(IWDG_FLAG_PVU))
	{}
    IWDG_SetPrescaler(prescale_reg);
    while (IWDG_GetFlagStatus(IWDG_FLAG_RVU))
    {}
    IWDG_SetReload(num_of_ms/prescale_val-1);
    IWDG_Enable();
}
#endif
/*
 *
 */
err_t InitExtUnit(void) {
 u32 Offset;
 uint8_t i, j, k;
 uint8_t bCRC;

// 	 Offset = OFFSET_PCBSETING + PAGE_SIZE;
 	 for (i = 1; i < NMB_UNIT; i++)
 	 {
// 		 sEEPROM_ReadBuffer((uint8_t*)&PcbSeting, Offset, sizeof(PcbSeting_t));
 		 bCRC = CRC8((uint8_t*)&PcbSeting, sizeof(PcbSeting_t)-1);
 		 if ((bCRC != PcbSeting.bCRC) || (bCRC == 0xff) ||
 			 (GPIO_ReadInputDataBit(BUTT1_PORT, BUTT1_PIN) == Bit_RESET)) {
 			 for (j = 0; j < NMB_ADC; j++)
 			 {
				 PcbSeting.eInpOn[j] = 30;
				 PcbSeting.eInpOff[j] = 50;
				 PcbSeting.eInpShort[j] = 0;
				 PcbSeting.eInpBreak[j] = 180;
 			 }
// 			 PcbSeting.InpAddr = START_INP_ADDR + i;
// 			 PcbSeting.OutpAddr = START_INP_ADDR + i;
 			 PcbSeting.Conf.b.InpActive = 0;
 			 PcbSeting.Conf.b.OutpActive = 0;
 			 PcbSeting.Conf.b.UnitType = DIO_UNIT;
 			 PcbSeting.bCRC = CRC8((uint8_t*)&PcbSeting, sizeof(PcbSeting_t)-1);
// 			 sEEPROM_WriteBuffer((uint8_t*)&PcbSeting, Offset, sizeof(PcbSeting_t));
 		 }
 		 PCB_Conf[i].Conf.d8 = PcbSeting.Conf.d8;
		 PCB_Conf[i].InpAddr = PcbSeting.InpAddr;
		 PCB_Conf[i].OutpAddr = PcbSeting.OutpAddr;
		 PCB_Conf[i].Conf.b.I2C_Error = 0;
		 PCB_Conf[i].Conf.b.I2C_ErrorCnt = 0;
		 if (PCB_Conf[i].Conf.b.InpActive) {
//			 CAN_Buff[0] = PLC_SET_SETING;
			 k = 1;
			 for (j = 0; j < NMB_ADC; j++)
			 {
				 CAN_Buff[k] = PcbSeting.eInpOn[j];
				 CAN_Buff[k + 1] = PcbSeting.eInpOff[j];
				 CAN_Buff[k + 2] = PcbSeting.eInpShort[j];
				 CAN_Buff[k + 3] = PcbSeting.eInpBreak[j];
				 k += 4;
			 }
		 }
 		 rY[i].BYTE = 0x00;
// 		 Offset += PAGE_SIZE;
 	 }
 	 return ERR_OK;
}
/**
 *
 */
err_t InitUnit(void) {
 uint8_t j, k;
 uint8_t bCRC;
 err_t ret = ERR_OK;

	 PCB_Wrk.d8 = 0;
// 	 sEEPROM_ReadBuffer((uint8_t*)&PcbSeting, OFFSET_PCBSETING, sizeof(PcbSeting_t));
 	 bCRC = CRC8((uint8_t*)&PcbSeting, sizeof(PcbSeting_t)-1);
	 if ((bCRC != PcbSeting.bCRC) || (bCRC == 0xff) ||
		 (GPIO_ReadInputDataBit(BUTT1_PORT, BUTT1_PIN) == Bit_RESET)) {
 		 for (j = 0; j < NMB_ADC; j++)
 		 {
 			 PcbSeting.eInpOn[j] = 30;
 			 PcbSeting.eInpOff[j] = 50;
 			 PcbSeting.eInpShort[j] = 0;
 			 PcbSeting.eInpBreak[j] = 180;
 		 }
// 		 PcbSeting.InpAddr = START_INP_ADDR;
// 		 PcbSeting.OutpAddr = START_OUTP_ADDR;
		 PcbSeting.Conf.b.InpActive = 1;
		 PcbSeting.Conf.b.OutpActive = 1;
		 PcbSeting.bCRC = CRC8((uint8_t*)&PcbSeting, sizeof(PcbSeting_t)-1);
//		 sEEPROM_WriteBuffer((uint8_t*)&PcbSeting, OFFSET_PCBSETING, sizeof(PcbSeting_t));
 	 }
 	 PCB_Conf[0].Conf.d8 = PcbSeting.Conf.d8;
 	 PCB_Conf[0].InpAddr = PcbSeting.InpAddr;
 	 PCB_Conf[0].OutpAddr = PcbSeting.OutpAddr;
 	 PCB_Conf[0].Conf.b.I2C_Error = 0;
 	 PCB_Conf[0].Conf.b.I2C_ErrorCnt = 0;
 	 if (PCB_Conf[0].Conf.b.OutpActive) {
 		 OwnRelay(0x00);
 	 }
// 	 PCA9554_Buff[0] = PLC_GET_CURR_ADDR;
 	 for (k = 0; k < 5; k++)
 	 {
// 		 I2cReadRequest(START_INP_ADDR, PCA9554_Buff, 1);
// 		 ret = WaitCompete();
 		 if (ret == ERR_OK) {
 			 break;
 		 }
 		 vTaskDelay(10);
 	 }
 	 if (ret != ERR_OK) {
 		 SysPSW->w.InpError = 1;
 		 return ret;
 	 }
 //	 OwnAddrCan = CAN_DIO_ADDRESS | START_INP_ADDR | (uint32_t)PCA9554_Buff[0];
 	 if (PCB_Conf[0].Conf.b.InpActive) {
// 		 PCA9554_Buff[0] = PLC_SET_SETING;
 		 k = 1;
 		 for (j = 0; j < NMB_ADC; j++)
 		 {
 			 PCA9554_Buff[k] = PcbSeting.eInpOn[j];
 			 PCA9554_Buff[k+1] = PcbSeting.eInpOff[j];
 			 PCA9554_Buff[k+2] = PcbSeting.eInpShort[j];
 			 PCA9554_Buff[k+3] = PcbSeting.eInpBreak[j];
 			 k += 4;
 		 }
 	 	 for (k = 0; k < 5; k++)
 	 	 {
// 	 		 I2cWriteRequest(START_INP_ADDR, PCA9554_Buff, 1+NMB_ADC*4);
// 		 	 ret = WaitCompete();
 		 	 if (ret == ERR_OK) {
 		 		 break;
 		 	 }
 	 		 vTaskDelay(10);
 	 	 }
 		 if (ret != ERR_OK) {
 			 SysPSW->w.InpError = 1;
 			 return ret;
 		 }
	 }
 	 rY[0].BYTE = 0x00;
 	 PCB_Wrk.b.PCB_Ready = 1;
 	 vTaskDelay(5);
 	 return ret;
}
