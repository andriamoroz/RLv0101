/**
  ******************************************************************************
  *
  ******************************************************************************
  */ 


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __EEPROM_BASE_H
#define __EEPROM_BASE_H

/* Includes ------------------------------------------------------------------*/
#include "port.h"
#include "mbport.h"

/* Exported constants --------------------------------------------------------*/
#define NMB_ADC		8

#define DIO_UNIT					0
#define AI_UNIT						1
#define AMP_UNIT					2
#define UPS_UNIT					3

#define	CAN_DIO_ADDRESS				((uint32_t)0x000)
#define	CAN_AI_ADDRESS				((uint32_t)0x100)
#define	CAN_AMP_ADDRESS				((uint32_t)0x200)
#define	CAN_AIO_ADDRESS				((uint32_t)0x300)
/* Exported types ------------------------------------------------------------*/

typedef union {
  uint8_t d8;
  struct {
	  uint8_t Reserv		: 1;
	  uint8_t StopBits		: 1;
	  uint8_t Active		: 1;
	  uint8_t Master		: 1;
	  uint8_t NmbUnit		: 4;
  } b;
} RS485_Conf_t;

typedef union {
  uint8_t d8;
  struct {
	  uint8_t Reserv		: 3;
	  uint8_t ConnPCB		: 3;
	  uint8_t UseLCD		: 1;
	  uint8_t UseKeypad		: 1;
  } b;
} UnitConf_t;

typedef struct {
	uint32_t ulBaudRate;
	uint8_t ucDataBits;
	eMBParity eParity;
	uint8_t Address;
	RS485_Conf_t Config;
} RS485_Port_t;

typedef struct {
	RS485_Port_t SlavePort;
	UnitConf_t Conf;
	uint8_t StartAddr;
	uint16_t wCRC;
} UnitSeting_t;

typedef union {
  uint8_t d8;
  struct {
	  uint8_t Reserv		: 4;
	  uint8_t PCB_Ready		: 1;
	  uint8_t PCB_Restart	: 1;
	  uint8_t Blink	: 1;
	  uint8_t Error	: 1;
  } b;
} PCB_Wrk_t;

typedef union {
  uint8_t d8;
  struct {
	  uint8_t Reserv		: 1;
	  uint8_t UnitType	: 1;
	  uint8_t I2C_ErrorCnt	: 3;
	  uint8_t I2C_Error		: 1;
	  uint8_t InpActive		: 1;
	  uint8_t OutpActive	: 1;
  } b;
} PCB_Conf_t;

typedef struct {
	uint8_t eInpOn[NMB_ADC];
	uint8_t eInpOff[NMB_ADC];
	uint8_t eInpShort[NMB_ADC];
	uint8_t eInpBreak[NMB_ADC];
	uint8_t InpAddr;
	uint8_t OutpAddr;
	PCB_Conf_t Conf;
	uint8_t bCRC;
} PcbSeting_t;

typedef union {
  uint8_t d8;
  struct {
	  uint8_t Reserv		: 3;
	  uint8_t NmbUnit		: 3;
	  uint8_t Execution		: 1;
	  uint8_t Complete		: 1;
  } b;
} StatePLC_t;

#define PLC_NO_COMM		0xff
typedef struct {
	uint8_t	Comm;
	StatePLC_t State;
	uint8_t Data[sizeof(PcbSeting_t) + 1];
} CommPLC_t;

/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */

#endif /*__EEPROM_BASE_H */

/************************ END OF FILE ****/
