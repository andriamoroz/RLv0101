#ifndef USER_APP
#define USER_APP
/* ----------------------- Modbus includes ----------------------------------*/
#include "main.h"
#include "mb.h"
#include "mbconfig.h"
#include "mbframe.h"
#include "mbutils.h"
#include "EEPROM_Base.h"
#include "system.h"
/* -----------------------Master Defines -------------------------------------*/
#define M_DISCRETE_INPUT_START        0
#define M_DISCRETE_INPUT_NDISCRETES   16
#define M_COIL_START                  0
#define M_COIL_NCOILS                 64
#define M_REG_INPUT_START             0
#define M_REG_INPUT_NREGS             20
#define M_REG_HOLDING_START           0
#define M_REG_HOLDING_NREGS           8*3
/* master mode: holding register's all address */
#define M_HD_RESERVE                  0
/* master mode: input register's all address */
#define M_IN_RESERVE                  0
/* master mode: coil's all address */
#define M_CO_RESERVE                  0
/* master mode: discrete's all address */
#define M_DI_RESERVE                  0

/* -----------------------Slave Defines -------------------------------------*/
#define S_DISCRETE_START_X        		0
#define S_DISCRETE_NDISCRETES_X   		(_X_num)
#define S_DISCRETE_START_ERR        	256
#define S_DISCRETE_NDISCRETES_ERR   	(_X_num)
#define S_COIL_START_Y                  0
#define S_COIL_NCOILS_Y                 _Y_num
#define S_COIL_START_S                  256
#define S_COIL_NCOILS_S                 _S_num

#define S_REG_INPUT_START_X         	(0)
#define S_REG_INPUT_NREGS_X				(_X_num)
#define S_REG_HOLDING_START_Y         	(0)
#define S_REG_HOLDING_NREGS_Y			(_Y_num)
#define S_REG_HOLDING_START_S         	(512)
#define S_REG_HOLDING_NREGS_S			(_S_num)
#define S_REG_HOLDING_START_PSW        	(1000)
#define S_REG_HOLDING_NREGS_PSW			(1)
#define S_REG_HOLDING_START_COMM      	(1010)
#define S_REG_HOLDING_NREGS_COMM		(2)
#define S_REG_HOLDING_START_BUFF     	(1020)
#define S_REG_HOLDING_NREGS_BUFF		(32)
#define D_REG_HOLDING_START_BUFF     	(2000)
#define D_REG_HOLDING_NMB				(_D_num)

#define S_REG_HOLDING_START_PSW_BUFF    (0)
#define S_REG_HOLDING_START_COMM_BUFF	(S_REG_HOLDING_START_PSW_BUFF + S_REG_HOLDING_NREGS_PSW)
#define S_REG_HOLDING_START_BUFF_BUFF   (S_REG_HOLDING_START_COMM_BUFF + S_REG_HOLDING_NREGS_COMM)
#define S_REG_HOLDING_NREGS_BUFF_BUFF 	(S_REG_HOLDING_NREGS_PSW+S_REG_HOLDING_NREGS_COMM+S_REG_HOLDING_NREGS_BUFF)
/* salve mode: holding register's all address */
#define S_HD_RESERVE                  0
#define S_HD_CPU_USAGE_MAJOR          1
#define S_HD_CPU_USAGE_MINOR          2
/* salve mode: input register's all address */
#define S_IN_RESERVE                  0
/* salve mode: coil's all address */
#define S_CO_RESERVE                  0
/* salve mode: discrete's all address */
#define S_DI_RESERVE                  0


#endif
