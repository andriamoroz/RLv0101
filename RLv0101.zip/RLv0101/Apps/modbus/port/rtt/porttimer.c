/*
 * FreeModbus Libary: RT-Thread Port
 * Copyright (C) 2013 Armink <armink.ztl@gmail.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * File: $Id: porttimer.c,v 1.60 2013/08/13 15:07:05 Armink $
 */

/* ----------------------- Platform includes --------------------------------*/
#include "port.h"

/* ----------------------- Modbus includes ----------------------------------*/
#include "mb.h"
#include "mbport.h"
#include "stm32f10x.h"

//static USHORT usTimerOut;

/* ----------------------- static functions ---------------------------------*/
/* ----------------------- Start implementation -----------------------------*/
BOOL xMBPortTimersInit(USHORT usTim1Timerout50us) {
 TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
 NVIC_InitTypeDef NVIC_InitStructure;

 	 /* TIM2 clock enable */
 	 RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
 	 /* -----------------------------------------------------------------------
  	  TIM2CLK = 72 MHz, TIM2 counter clock = 1 MHz
  	  Period is configured with the Sampling_Period - 1
  	  ----------------------------------------------------------------------- */
 	 /* Time base configuration */
 	 TIM_TimeBaseStructure.TIM_Period = (uint16_t)usTim1Timerout50us - 1;
 	 TIM_TimeBaseStructure.TIM_Prescaler = (uint16_t)(SystemCoreClock / 10000) - 1;
 	 TIM_TimeBaseStructure.TIM_ClockDivision = 0x0;
 	 TIM_TimeBaseStructure.TIM_CounterMode =  TIM_CounterMode_Up;
 	 TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
 	 TIM_ARRPreloadConfig(TIM2, ENABLE);
// 	 TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
 	 /* Enable the TIM2 global Interrupt */
 	 NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
 	 NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 12;
 	 NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
 	 NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
 	 NVIC_Init(&NVIC_InitStructure);
 	 NVIC_EnableIRQ(TIM2_IRQn);
 	 return TRUE;
}

void vMBPortTimersEnable(void) {
    TIM2->CNT = 0;
	/* Enable the TIM Counter */
	TIM2->CR1 |= (uint16_t)TIM_CR1_CEN;
	/* Clear the IT pending Bit */
	TIM2->SR = (uint16_t)~TIM_IT_Update;
	/* Enable TIM2 update interrupt */
	TIM2->DIER |= TIM_IT_Update;
}

void vMBPortTimersDisable(void) {
	/* Disable TIM2 update interrupt */
	TIM2->DIER &= (uint16_t)~TIM_IT_Update;
}

/**
  * @brief  This function handles TIM4 interrupt request.
  * @param  None
  * @retval : None
  */
void TIM2_IRQHandler(void) {
	if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET) {
		TIM2->SR = (uint16_t)~TIM_IT_Update;
		(void)pxMBPortCBTimerExpired();
     }
}
