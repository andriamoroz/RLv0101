/*
 * FreeModbus Libary: RT-Thread Port
 * Copyright (C) 2013 Armink <armink.ztl@gmail.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * File: $Id: portserial.c,v 1.60 2013/08/13 15:07:05 Armink $
 */

#include "port.h"

/* ----------------------- Modbus includes ----------------------------------*/
#include "mb.h"
#include "mbport.h"
#include "Board.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_gpio.h"

volatile UCHAR LastByte;
/* ----------------------- Static variables ---------------------------------*/

/* ----------------------- Defines ------------------------------------------*/
/* serial transmit event */
#define EVENT_SERIAL_TRANS_START    (1<<0)

/* ----------------------- static functions ---------------------------------*/
static void prvvUARTTxReadyISR(void);
static void prvvUARTRxISR(void);

/* ----------------------- Start implementation -----------------------------*/
void vMBPortSerialEnable(BOOL xRxEnable, BOOL xTxEnable) {
    /* If xRXEnable enable serial receive interrupts. If xTxENable enable
     * transmitter empty interrupts.
     */
	if (xRxEnable) {
		RS485_DE_LOW;
	    USART_ITConfig(RS485, USART_IT_RXNE, ENABLE);
	} else {
	    USART_ITConfig(RS485, USART_IT_RXNE, DISABLE);
	}
	if (xTxEnable) {
		RS485_DE_HIGH;
	    USART_ITConfig(RS485, USART_IT_TXE, ENABLE);
	} else {
		LastByte = 0;
	    USART_ITConfig(RS485, USART_IT_TXE, DISABLE);
	}
}

BOOL xMBPortSerialInit(ULONG ulBaudRate, UCHAR ucDataBits, eMBParity eParity, UCHAR ucStopBits) {
 NVIC_InitTypeDef NVIC_InitStructure;
 GPIO_InitTypeDef GPIO_InitStructure;
 USART_InitTypeDef USART_InitStructure;

   /* Enable USART1 and GPIOA clock */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);
    /* Configure the GPIOs */
    /* Configure the GPIO_DE pin */
    GPIO_InitStructure.GPIO_Pin = RS485_DE_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(RS485_DE_PORT, &GPIO_InitStructure);
    /* Configure USART1 Tx (PA.09) as alternate function push-pull */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /* Configure USART1 Rx (PA.10) as input floating */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /* Configure the USART1 */
    /* USART1 configuration ------------------------------------------------------*/
    /* USART1 configured as follow:
        - One Stop Bit
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
        - USART Clock disabled
        - USART CPOL: Clock is active low
        - USART CPHA: Data is captured on the middle
        - USART LastBit: The clock pulse of the last data bit is not output to
            the SCLK pin
     */
    USART_InitStructure.USART_BaudRate = ulBaudRate;
    switch(ucDataBits)
    {
    	case 8:
    		USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    		break;
    	case 9:
    		USART_InitStructure.USART_WordLength = USART_WordLength_9b;
    		break;
    	default:
    		return FALSE;
    }
    switch(ucStopBits)
    {
    	case 0:
    		USART_InitStructure.USART_StopBits = USART_StopBits_1;
    		break;
    	case 1:
    		USART_InitStructure.USART_StopBits = USART_StopBits_1_5;
    		break;
    	case 2:
    		USART_InitStructure.USART_StopBits = USART_StopBits_2;
    		break;
    	default:
    		return FALSE;
    }
	switch(eParity)
	{
		case MB_PAR_NONE:
			USART_InitStructure.USART_Parity = USART_Parity_No;
			break;
		case MB_PAR_EVEN:
			USART_InitStructure.USART_Parity = USART_Parity_Even;
			break;
		case MB_PAR_ODD:
			USART_InitStructure.USART_Parity = USART_Parity_Odd;
			break;
		default:
			return FALSE;
	}
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &USART_InitStructure);
    GPIO_ResetBits(RS485_DE_PORT, RS485_DE_PIN);
//    RS485_DE_HIGH;
    /* NVIC Configuration */
    /* Enable the USARTx Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 5;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    /* Enable USART */
    USART_Cmd(RS485, ENABLE);
    /* Enable the USART Receive interrupt: this interrupt is generated when the
     * USART1 receive data register is not empty */
//    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    vMBPortSerialEnable(FALSE, FALSE);
    return TRUE;
}

BOOL xMBPortSerialPutByte(CHAR ucByte) {
	if (LastByte) {
	    USART_ITConfig(RS485, USART_IT_TXE, DISABLE);
	    USART_ITConfig(RS485, USART_IT_TC, ENABLE);
	}
	RS485->DR = ucByte;
    return TRUE;
}

BOOL xMBPortSerialGetByte(CHAR *pucByte) {
    *pucByte = RS485->DR;
    return TRUE;
}
/* 
 * Create an interrupt handler for the transmit buffer empty interrupt
 * (or an equivalent) for your target processor. This function should then
 * call pxMBFrameCBTransmitterEmpty( ) which tells the protocol stack that
 * a new character can be sent. The protocol stack will then call 
 * xMBPortSerialPutByte( ) to send the character.
 */
static void prvvUARTTxReadyISR(void) {
    pxMBFrameCBTransmitterEmpty();
}
/* 
 * Create an interrupt handler for the receive interrupt for your target
 * processor. This function should then call pxMBFrameCBByteReceived( ). The
 * protocol stack will then call xMBPortSerialGetByte( ) to retrieve the
 * character.
 */
static void prvvUARTRxISR(void) {
    pxMBFrameCBByteReceived();
}

static uint8_t uByte;

void RS485_IRQHandler(void) {
    if (USART_GetITStatus(RS485, USART_IT_RXNE) != RESET) {
    	prvvUARTRxISR();
    } else if (USART_GetITStatus(RS485, USART_IT_TXE) != RESET) {
    	USART_ClearITPendingBit(RS485, USART_IT_TXE);
    	prvvUARTTxReadyISR();
    } else if (USART_GetITStatus(RS485, USART_IT_TC) != RESET) {
    	USART_ClearITPendingBit(RS485, USART_IT_TC);
    	prvvUARTTxReadyISR();
    } else if (USART_GetITStatus(RS485, USART_IT_LBD) != RESET) {
    	USART_ClearITPendingBit(RS485, USART_IT_LBD);
    } else {
    	uByte = RS485->DR;
    }
}
