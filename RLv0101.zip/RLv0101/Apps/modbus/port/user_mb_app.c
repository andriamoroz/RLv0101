/*
 * FreeModbus Libary: user callback functions and buffer define in slave mode
 * Copyright (C) 2013 Armink <armink.ztl@gmail.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * File: $Id: user_mb_app.c,v 1.60 2013/11/23 11:49:05 Armink $
 */
#include "main.h"
#include "user_mb_app.h"
#include "system.h"

extern osSemaphoreId CommRcv_Sem;
TYPE_BIT_BYTE rX[_X_BYTE];
TYPE_BIT_BYTE rY[_Y_BYTE], rYw[_Y_BYTE], rYi[_Y_BYTE];
TYPE_BIT_BYTE rS[_S_BYTE];
TYPE_BIT_BYTE *ErrX;
int16_t _D[_D_num];
extern UnitSeting_t *pUnitSeting;
extern PcbSeting_t *pPcbSeting;
/*------------------------Slave mode use these variables----------------------*/
USHORT usSRegHoldBuf[S_REG_HOLDING_NREGS_BUFF_BUFF];

/**
 * Modbus slave input register callback function.
 *
 * @param pucRegBuffer input register buffer
 * @param usAddress input register address
 * @param usNRegs input register number
 *
 * @return result
 */
eMBErrorCode eMBRegInputCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNRegs) {
 uint8_t usMask;
 USHORT Var;
 USHORT Index;

    /* it already plus one in modbus function method. */
    usAddress--;
    if ((usAddress < S_REG_INPUT_START_X) || ((usAddress + usNRegs) > (S_REG_INPUT_START_X + S_REG_INPUT_NREGS_X))) {
    	return MB_ENOREG;
    }
   	Index = usAddress / 8;
   	usMask = 1 << (usAddress % 8);

    while(usNRegs > 0)
    {
    	Var = 0;
    	if (*((uint8_t*)rX+Index) & usMask) {
    		Var = 1;
    	}
    	if (*((uint8_t*)ErrX+Index) & usMask) {
    		Var |= 0x100;
    	}
    	*pucRegBuffer++ = (UCHAR)(Var >> 8);
    	*pucRegBuffer++ = (UCHAR)(Var & 0xFF);
    	usMask <<= 1;
    	if (usMask == 0) {
    		Index++;
    		usMask = 1;
    	}
    	usNRegs--;
    }
    return MB_ENOERR;
}
/**
 * Modbus slave holding register callback function.
 *
 * @param pucRegBuffer holding register buffer
 * @param usAddress holding register address
 * @param usNRegs holding register number
 * @param eMode read or write
 *
 * @return result
 */
eMBErrorCode eMBRegHoldingCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNRegs, eMBRegisterMode eMode) {
 eMBErrorCode eStatus = MB_ENOERR;
 uint8_t usMask, rqMode;
 USHORT Var;
 USHORT Index;
 USHORT *pusRegHoldingBuf;
// u32 Offset;

    pusRegHoldingBuf = usSRegHoldBuf;
    /* it already plus one in modbus function method. */
    usAddress--;
    if ((usAddress >= S_REG_HOLDING_START_Y) && (usAddress + usNRegs <= (S_REG_HOLDING_START_Y + S_REG_HOLDING_NREGS_Y))) {
    	rqMode = COIL_MODE;
    } else if ((usAddress >= S_REG_HOLDING_START_S) && (usAddress + usNRegs <= (S_REG_HOLDING_START_S + S_REG_HOLDING_NREGS_S))) {
    	rqMode = COIL_S_MODE;
    } else if ((usAddress >= S_REG_HOLDING_START_PSW) && (usAddress + usNRegs <= (S_REG_HOLDING_START_PSW + S_REG_HOLDING_NREGS_PSW))) {
    	rqMode = PSW_MODE;
    } else if ((usAddress >= S_REG_HOLDING_START_COMM) && (usAddress + usNRegs <= (S_REG_HOLDING_START_COMM + S_REG_HOLDING_NREGS_COMM))) {
    	rqMode = CMD_MODE;
    } else if ((usAddress >= S_REG_HOLDING_START_BUFF) && (usAddress + usNRegs <= (S_REG_HOLDING_START_BUFF + S_REG_HOLDING_NREGS_BUFF))) {
    	rqMode = BUFF_MODE;
    } else if ((usAddress >= D_REG_HOLDING_START_BUFF) && (usAddress + usNRegs <= (D_REG_HOLDING_START_BUFF + D_REG_HOLDING_NMB))) {
    	rqMode = REG_MODE;
        pusRegHoldingBuf = (USHORT*)&_D[0];
    }  else {
    	return MB_ENOREG;
    }
    switch(eMode)
    {
    	/* read current register values from the protocol stack. */
    	case MB_REG_READ:
    		if ((rqMode == COIL_MODE) || (rqMode == COIL_S_MODE)) {
    			Index = usAddress / 8;
    			usMask = 1 << (usAddress % 8);
    		} else if (rqMode == PSW_MODE) {
    			Index = S_REG_HOLDING_START_PSW_BUFF;
    		} else if (rqMode == CMD_MODE) {
    			Index = S_REG_HOLDING_START_COMM_BUFF;
    		} else if (rqMode == BUFF_MODE) {
    			Index = S_REG_HOLDING_START_BUFF_BUFF;
    		} else {
    			Index = usAddress - D_REG_HOLDING_START_BUFF;
    		}
    		while(usNRegs > 0)
    		{
    			Var = 0;
    			if (rqMode == COIL_MODE) {
    				if (*((uint8_t*)rY+Index) & usMask) {
    					Var = 1;
    				}
    				*pucRegBuffer++ = (UCHAR)(Var >> 8);
    				*pucRegBuffer++ = (UCHAR)(Var & 0xFF);
    				usMask <<= 1;
    				if (usMask == 0) {
    					Index++;
    					usMask = 1;
    				}
    			} else if (rqMode == COIL_S_MODE) {
    				if (*((uint8_t*)rS+Index) & usMask) {
    					Var = 1;
    				}
    				*pucRegBuffer++ = (UCHAR)(Var >> 8);
    				*pucRegBuffer++ = (UCHAR)(Var & 0xFF);
    				usMask <<= 1;
    				if (usMask == 0) {
    					Index++;
    					usMask = 1;
    				}
    			} else {
    				*pucRegBuffer++ = (UCHAR)(pusRegHoldingBuf[Index] >> 8);
    				*pucRegBuffer++ = (UCHAR)(pusRegHoldingBuf[Index] & 0xFF);
    				Index++;
    			}
    			usNRegs--;
    		}
    		break;
    		/* write current register values with new values from the protocol stack. */
    	case MB_REG_WRITE:
    		if ((rqMode == COIL_MODE) || (rqMode == COIL_S_MODE)) {
    			Index = usAddress / 8;
    			usMask = 1 << (usAddress % 8);
    		}  else if (rqMode == PSW_MODE) {
    			Index = S_REG_HOLDING_START_PSW_BUFF;
    		} else if (rqMode == CMD_MODE) {
    			Index = S_REG_HOLDING_START_COMM_BUFF;
    		} else if (rqMode == BUFF_MODE) {
    			Index = S_REG_HOLDING_START_BUFF_BUFF;
    		} else {
//    			Index = 0;
    			Index = usAddress - D_REG_HOLDING_START_BUFF;
    		}
    		while(usNRegs > 0)
    		{
    			if (rqMode == COIL_MODE) {
    				Var = *pucRegBuffer++ << 8;
    				Var |= *pucRegBuffer++;
    				if (Var) {
    					*((uint8_t*)rYw+Index) |= usMask;
    				} else {
    					*((uint8_t*)rYw+Index) &= ~usMask;
    				}
					*((uint8_t*)rYi+Index) |= usMask;
    				usMask <<= 1;
    				if (usMask == 0) {
    					Index++;
    					usMask = 1;
    				}
    			} else if (rqMode == COIL_S_MODE) {
    				Var = *pucRegBuffer++ << 8;
    				Var |= *pucRegBuffer++;
    				if (Var) {
    					*((uint8_t*)rS+Index) |= usMask;
    				} else {
    					*((uint8_t*)rS+Index) &= ~usMask;
    				}
    				usMask <<= 1;
    				if (usMask == 0) {
    					Index++;
    					usMask = 1;
    				}
    			} else {
    				pusRegHoldingBuf[Index] = *pucRegBuffer++ << 8;
    				pusRegHoldingBuf[Index] |= *pucRegBuffer++;
    				Index++;
    			}
    			usNRegs--;
    		}
    		if (rqMode == CMD_MODE) {
    			osSemaphoreRelease(CommRcv_Sem);
    		}
    		break;
   	}
    return eStatus;
}
/**
 * Modbus slave coils callback function.
 *
 * @param pucRegBuffer coils buffer
 * @param usAddress coils address
 * @param usNCoils coils number
 * @param eMode read or write
 *
 * @return result
 */
eMBErrorCode eMBRegCoilsCB(UCHAR * pucRegBuffer, USHORT usAddress, USHORT usNCoils, eMBRegisterMode eMode) {
 eMBErrorCode eStatus = MB_ENOERR;
 USHORT iRegIndex, iRegBitIndex, iNReg;
 USHORT usByteOffset;
 USHORT usMask;
 UCHAR *pucCoilBuf;
 USHORT usCoilStart;

    iNReg =  usNCoils / 8 + 1;
    /* it already plus one in modbus function method. */
    usAddress--;
    if ((usAddress >= S_COIL_START_Y) && (usAddress + usNCoils <= (S_COIL_START_Y + S_COIL_NCOILS_Y))) {
    	usCoilStart = S_COIL_START_Y;
        if (eMode == MB_REG_READ) {
        	pucCoilBuf = (UCHAR *)rY;
        } else {
        	pucCoilBuf = (UCHAR *)rYw;
        }
    } else if ((usAddress >= S_COIL_START_S) && (usAddress + usNCoils <= (S_COIL_START_S + S_COIL_NCOILS_S))) {
    	usCoilStart = S_COIL_START_S;
       	pucCoilBuf = (UCHAR *)rS;
    } else {
    	return MB_ENOREG;
    }
    iRegIndex = (USHORT) (usAddress - usCoilStart) / 8;
    iRegBitIndex = (USHORT) (usAddress - usCoilStart) % 8;
    switch(eMode)
    {
    	/* read current coil values from the protocol stack. */
    	case MB_REG_READ:
    		while(iNReg > 0)
    		{
    			*pucRegBuffer++ = xMBUtilGetBits(&pucCoilBuf[iRegIndex++], iRegBitIndex, 8);
    			iNReg--;
    		}
    		pucRegBuffer--;
    		/* last coils */
    		usNCoils = usNCoils % 8;
    		/* filling zero to high bit */
    		*pucRegBuffer = *pucRegBuffer << (8 - usNCoils);
    		*pucRegBuffer = *pucRegBuffer >> (8 - usNCoils);
    		break;
    		/* write current coil values with new values from the protocol stack. */
    	case MB_REG_WRITE:
    		while(iNReg > 1)
    		{
    			xMBUtilSetBits(&pucCoilBuf[iRegIndex], iRegBitIndex, 8, *pucRegBuffer++);
    			if (usCoilStart == S_COIL_START_Y) {
    			    usByteOffset = (USHORT)((iRegBitIndex) / 8);
    			    usMask = (USHORT)((1 << (USHORT)8) - 1);
    			    usMask <<= iRegBitIndex - usByteOffset * 8;
    				xMBUtilSetBits((uint8_t*)&rYi[iRegIndex], iRegBitIndex, 8, usMask);
    			}
    			iRegIndex++;
    			iNReg--;
    		}
    		/* last coils */
    		usNCoils = usNCoils % 8;
    		/* xMBUtilSetBits has bug when ucNBits is zero */
    		if (usNCoils != 0) {
    			xMBUtilSetBits(&pucCoilBuf[iRegIndex], iRegBitIndex, usNCoils, *pucRegBuffer++);
    			if (usCoilStart == S_COIL_START_Y) {
    				xMBUtilSetBits((uint8_t*)&rYi[iRegIndex], iRegBitIndex, 8, 0x1);
    			}
    			iRegIndex++;
    		}
    		break;
    }
    return eStatus;
}
/**
 * Modbus slave discrete callback function.
 *
 * @param pucRegBuffer discrete buffer
 * @param usAddress discrete address
 * @param usNDiscrete discrete number
 *
 * @return result
 */
eMBErrorCode eMBRegDiscreteCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNDiscrete) {
 eMBErrorCode eStatus = MB_ENOERR;
 USHORT iRegIndex, iRegBitIndex, iNReg;
 UCHAR *pucDiscreteInputBuf;
 USHORT usDiscreteInputStart;

    iNReg =  usNDiscrete / 8 + 1;
    /* it already plus one in modbus function method. */
    usAddress--;
    if ((usAddress >= S_DISCRETE_START_X) && (usAddress + usNDiscrete <= (S_DISCRETE_START_X + S_DISCRETE_NDISCRETES_X))) {
    	usDiscreteInputStart = S_DISCRETE_START_X;
    	pucDiscreteInputBuf = (UCHAR *)rX;
    } else if ((usAddress >= S_DISCRETE_START_ERR) && (usAddress + usNDiscrete <= (S_DISCRETE_START_ERR + S_DISCRETE_NDISCRETES_ERR))) {
    	usDiscreteInputStart = S_DISCRETE_START_ERR;
    	pucDiscreteInputBuf = (UCHAR *)ErrX;
    } else {
    	return MB_ENOREG;
    }
    iRegIndex = (USHORT)(usAddress - usDiscreteInputStart) / 8;
    iRegBitIndex = (USHORT)(usAddress - usDiscreteInputStart) % 8;
    while(iNReg > 0)
    {
    	*pucRegBuffer++ = xMBUtilGetBits(&pucDiscreteInputBuf[iRegIndex++], iRegBitIndex, 8);
    	iNReg--;
    }
    pucRegBuffer--;
    /* last discrete */
    usNDiscrete = usNDiscrete % 8;
    /* filling zero to high bit */
    *pucRegBuffer = *pucRegBuffer << (8 - usNDiscrete);
    *pucRegBuffer = *pucRegBuffer >> (8 - usNDiscrete);
    return eStatus;
}

