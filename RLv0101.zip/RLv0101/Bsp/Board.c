/**
  ******************************************************************************
  *
  ******************************************************************************
  */  
  
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_pwr.h"
#include "stm32f10x_rtc.h"
#include "Board.h"
#include "port.h"
#include "mbport.h"
#include "system.h"

extern SysPSW_t *SysPSW;

GPIO_TypeDef*  Relay_ports[] = {RELAY1_PORT,
							  	RELAY2_PORT,
								RELAY3_PORT,
								RELAY4_PORT,
								RELAY5_PORT,
								RELAY6_PORT,
								RELAY7_PORT,
								RELAY8_PORT};

const uint16_t Relay_pins[] = {RELAY1_PIN,
							   RELAY2_PIN,
							   RELAY3_PIN,
							   RELAY4_PIN,
							   RELAY5_PIN,
							   RELAY6_PIN,
							   RELAY7_PIN,
							   RELAY8_PIN};
/**
 */
void MainPWR_Init(void) {
 GPIO_InitTypeDef GPIO_InitStructure;

    /* Enable GPIOA clock */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    /* Configure the GPIOs */
    GPIO_InitStructure.GPIO_Pin = POWER_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(POWER_PORT, &GPIO_InitStructure);
    return;
}
/**
 */
void AmpOn_Init(void) {
 GPIO_InitTypeDef GPIO_InitStructure;

    /* Enable GPIOA clock */
    RCC_APB2PeriphClockCmd(AMP_ON_CLK, ENABLE);
    /* Configure the GPIOs */
    GPIO_InitStructure.GPIO_Pin = AMP_ON_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(AMP_ON_PORT, &GPIO_InitStructure);
    return;
}
/**
 */
void Master_Init(void) {
 GPIO_InitTypeDef GPIO_InitStructure;

    /* Enable GPIOA clock */
    RCC_APB2PeriphClockCmd(M_S_CLK, ENABLE);
    /* Configure the GPIOs */
    GPIO_InitStructure.GPIO_Pin = M_S_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(M_S_PORT, &GPIO_InitStructure);
	if (GPIO_ReadInputDataBit(M_S_PORT, M_S_PIN) == Bit_SET) {
		SysPSW->w.MasterMode = 1;
	}
    return;
}
/**
  */
void Init_ExtResetPin(void) {
 GPIO_InitTypeDef GPIO_InitStructure;

    /* Enable GPIOB clock */
    RCC_APB2PeriphClockCmd(EXT_RESETN_CLK, ENABLE);
    /* Configure the GPIOs */
    GPIO_InitStructure.GPIO_Pin = EXT_RESET_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(EXT_RESET_PORT, &GPIO_InitStructure);
    return;
}
/**
  */
void InpOn_Init(void) {
 GPIO_InitTypeDef GPIO_InitStructure;

 	 /* Enable GPIOA clock */
 	 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
 	 /* Configure the GPIOs */
	 GPIO_InitStructure.GPIO_Pin = INP_ON_PIN;
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	 GPIO_Init(INP_ON_PORT, &GPIO_InitStructure);
	 INP_ON_LOW;
}
/**
  */
void Led_Init(void) {
 GPIO_InitTypeDef GPIO_InitStructure;

 	 /* Enable GPIOA clock */
 	 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
 	 /* Configure the GPIOs */
	 GPIO_InitStructure.GPIO_Pin = RED_PIN;
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	 GPIO_Init(RED_PORT, &GPIO_InitStructure);
	 RED_OFF;
	 GPIO_InitStructure.GPIO_Pin = GREEN_PIN;
	 GPIO_Init(GREEN_PORT, &GPIO_InitStructure);
	 GREEN_OFF;
}
/**
  * @brief  Initializes the peripherals used by the SPI FLASH driver.
  * @param  None
  * @retval None
  */
void EEPROM_LowLevel_Init(void) {
 GPIO_InitTypeDef GPIO_InitStructure;

  	 /* Enable the SPI clock */
 	 EEPROM_SPI_CLK_INIT(EEPROM_SPI_CLK, ENABLE);
 	 /* Enable GPIO clocks */
  	 RCC_APB2PeriphClockCmd(EEPROM_SPI_SCK_GPIO_CLK | EEPROM_SPI_MISO_GPIO_CLK |
  			 	 	 	 	 EEPROM_SPI_MOSI_GPIO_CLK | EEPROM_SPI_CS_GPIO_CLK, ENABLE);
  	 /* SPI pins configuration *************************************************/
  	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  	 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	 /* SPI SCK pin configuration */
  	 GPIO_InitStructure.GPIO_Pin = EEPROM_SPI_SCK_PIN;
  	 GPIO_Init(EEPROM_SPI_SCK_PORT, &GPIO_InitStructure);
  	 /* SPI MOSI pin configuration */
  	 GPIO_InitStructure.GPIO_Pin =  EEPROM_SPI_MOSI_PIN;
  	 GPIO_Init(EEPROM_SPI_MOSI_PORT, &GPIO_InitStructure);
  	 /* SPI MISO pin configuration */
  	 GPIO_InitStructure.GPIO_Pin =  EEPROM_SPI_MISO_PIN;
  	 GPIO_Init(EEPROM_SPI_MISO_PORT, &GPIO_InitStructure);
  	 /* Configure sFLASH Card CS pin in output pushpull mode ********************/
  	 GPIO_InitStructure.GPIO_Pin = EEPROM_SPI_CS_PIN;
  	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	 GPIO_Init(EEPROM_SPI_CS_PORT, &GPIO_InitStructure);
}

void I2C2_init(void) {
 I2C_InitTypeDef  I2C_InitStructure;
 GPIO_InitTypeDef  GPIO_InitStructure;
 NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C2, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    /* Configure I2C_EE pins: SCL and SDA */
    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_10 | GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    /* I2C configuration */
    I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
    I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;
    I2C_InitStructure.I2C_OwnAddress1 = 0x38;
    I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
    I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
    I2C_InitStructure.I2C_ClockSpeed = 50000;//T_I2C_SPEED;
    /* I2C Peripheral Enable */
    I2C_Cmd(I2C2, ENABLE);
    /* Apply I2C configuration after enabling it */
    I2C_Init(I2C2, &I2C_InitStructure);
    /* Configure the NVIC for I2C*/
    NVIC_InitStructure.NVIC_IRQChannel = I2C2_ER_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 7;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    NVIC_InitStructure.NVIC_IRQChannel = I2C2_EV_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 6;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    I2C_ITConfig(I2C2, I2C_IT_ERR|I2C_IT_EVT/*|I2C_IT_BUF*/, ENABLE);
}

void TIM3_Config(void) {
 TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;

 	 RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
 	 /* Time base configuration */
 	 TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
 	 TIM_TimeBaseStructure.TIM_Period        = (uint16_t) (SystemCoreClock / 1000000) - 1;
 	 TIM_TimeBaseStructure.TIM_Prescaler     = 10000 - 1;
 	 TIM_TimeBaseStructure.TIM_ClockDivision = 0;
 	 TIM_TimeBaseStructure.TIM_CounterMode   = TIM_CounterMode_Up;
 	 TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
 	 TIM_SelectOutputTrigger(TIM3, TIM_TRGOSource_Update);
 	 TIM_Cmd(TIM3, ENABLE);
}

uint8_t xPortSerialInit(uint32_t ulBaudRate, uint8_t ucDataBits, eMBParity eParity, uint8_t ucStopBits) {
 NVIC_InitTypeDef NVIC_InitStructure;
 GPIO_InitTypeDef GPIO_InitStructure;
 USART_InitTypeDef USART_InitStructure;

   /* Enable USART1 and GPIOA clock */
    RCC_APB1PeriphClockCmd(RS232_CLK_ENABLE, ENABLE);
    RCC_APB2PeriphClockCmd(RS232_RX_GPIO_CLK_ENABLE | RS232_TX_GPIO_CLK_ENABLE, ENABLE);
    /* Configure the GPIOs */
    /* Configure USART1 Tx (PA.09) as alternate function push-pull */
    GPIO_InitStructure.GPIO_Pin = RS232_TX_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(RS232_TX_PORT, &GPIO_InitStructure);

    /* Configure USART1 Rx (PA.10) as input floating */
    GPIO_InitStructure.GPIO_Pin = RS232_RX_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(RS232_RX_PORT, &GPIO_InitStructure);

    /* Configure the USART1 */
    /* USART1 configuration ------------------------------------------------------*/
    /* USART1 configured as follow:
        - One Stop Bit
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
        - USART Clock disabled
        - USART CPOL: Clock is active low
        - USART CPHA: Data is captured on the middle
        - USART LastBit: The clock pulse of the last data bit is not output to
            the SCLK pin
     */
    USART_InitStructure.USART_BaudRate = ulBaudRate;
    switch(ucDataBits)
    {
    	case 8:
    		USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    		break;
    	case 9:
    		USART_InitStructure.USART_WordLength = USART_WordLength_9b;
    		break;
    	default:
    		return FALSE;
    }
    switch(ucStopBits)
    {
    	case 0:
    		USART_InitStructure.USART_StopBits = USART_StopBits_1;
    		break;
    	case 1:
    		USART_InitStructure.USART_StopBits = USART_StopBits_1_5;
    		break;
    	case 2:
    		USART_InitStructure.USART_StopBits = USART_StopBits_2;
    		break;
    	default:
    		return FALSE;
    }
	switch(eParity)
	{
		case MB_PAR_NONE:
			USART_InitStructure.USART_Parity = USART_Parity_No;
			break;
		case MB_PAR_EVEN:
			USART_InitStructure.USART_Parity = USART_Parity_Even;
			break;
		case MB_PAR_ODD:
			USART_InitStructure.USART_Parity = USART_Parity_Odd;
			break;
		default:
			return FALSE;
	}
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(RS232, &USART_InitStructure);
    /* NVIC Configuration */
    /* Enable the USARTx Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = RS232_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 10;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    /* Enable USART */
    USART_Cmd(RS232, ENABLE);
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
    USART_ITConfig(USART2, USART_IT_TC, ENABLE);
    return TRUE;
}
/**
  */
void Init_RelayPin(void) {
 GPIO_InitTypeDef GPIO_InitStructure;

 	 /* Enable the GPIO_LCD DB4 clock */
     RCC_APB2PeriphClockCmd(RELAY1_CLK_ENABLE, ENABLE);
	 /* Configure the GPIO_LCD DB4 pin */
	 GPIO_InitStructure.GPIO_Pin = RELAY1_PIN;
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	 GPIO_Init(RELAY1_PORT, &GPIO_InitStructure);
	 GPIO_WriteBit(RELAY1_PORT, RELAY1_PIN, Bit_RESET);
 	 /* Enable the GPIO_LCD DB5 clock */
	 RCC_APB2PeriphClockCmd(RELAY2_CLK_ENABLE, ENABLE);
	 /* Configure the GPIO_LCD DB5 pin */
	 GPIO_InitStructure.GPIO_Pin = RELAY2_PIN;
	 GPIO_Init(RELAY2_PORT, &GPIO_InitStructure);
	 GPIO_WriteBit(RELAY2_PORT, RELAY2_PIN, Bit_RESET);
 	 /* Enable the GPIO_LCD DB6 clock */
	 RCC_APB2PeriphClockCmd(RELAY3_CLK_ENABLE, ENABLE);
	 /* Configure the GPIO_LCD DB6 pin */
	 GPIO_InitStructure.GPIO_Pin = RELAY3_PIN;
	 GPIO_Init(RELAY3_PORT, &GPIO_InitStructure);
	 GPIO_WriteBit(RELAY3_PORT, RELAY3_PIN, Bit_RESET);
 	 /* Enable the GPIO_LCD DB7 clock */
	 RCC_APB2PeriphClockCmd(RELAY4_CLK_ENABLE, ENABLE);
	 /* Configure the GPIO_LCD DB7 pin */
	 GPIO_InitStructure.GPIO_Pin = RELAY4_PIN;
	 GPIO_Init(RELAY4_PORT, &GPIO_InitStructure);
	 GPIO_WriteBit(RELAY4_PORT, RELAY4_PIN, Bit_RESET);
 	 /* Enable the GPIO_LCD LIGHT clock */
	 RCC_APB2PeriphClockCmd(RELAY5_CLK_ENABLE, ENABLE);
	 /* Configure the GPIO_LCD LIGHT pin */
	 GPIO_InitStructure.GPIO_Pin = RELAY5_PIN;
	 GPIO_Init(RELAY5_PORT, &GPIO_InitStructure);
	 GPIO_WriteBit(RELAY5_PORT, RELAY5_PIN, Bit_RESET);
 	 /* Enable the GPIO_LCD EN clock */
	 RCC_APB2PeriphClockCmd(RELAY6_CLK_ENABLE, ENABLE);
	 /* Configure the GPIO_LCD EN pin */
	 GPIO_InitStructure.GPIO_Pin = RELAY6_PIN;
	 GPIO_Init(RELAY6_PORT, &GPIO_InitStructure);
	 GPIO_WriteBit(RELAY6_PORT, RELAY6_PIN, Bit_RESET);
 	 /* Enable the RELAY7 clock */
	 RCC_APB2PeriphClockCmd(RELAY7_CLK_ENABLE, ENABLE);
	 /* Configure the RELAY7 pin */
	 GPIO_InitStructure.GPIO_Pin = RELAY7_PIN;
	 GPIO_Init(RELAY7_PORT, &GPIO_InitStructure);
	 GPIO_WriteBit(RELAY7_PORT, RELAY7_PIN, Bit_RESET);
 	 /* Enable the RELAY8 clock */
	 RCC_APB2PeriphClockCmd(RELAY8_CLK_ENABLE, ENABLE);
	 /* Configure the RELAY8 pin */
	 GPIO_InitStructure.GPIO_Pin = RELAY8_PIN;
	 GPIO_Init(RELAY8_PORT, &GPIO_InitStructure);
	 GPIO_WriteBit(RELAY8_PORT, RELAY8_PIN, Bit_RESET);
}
/**
  */
void RelayOn(uint8_t Rl) {
	Relay_ports[Rl]->BSRR = (uint32_t)Relay_pins[Rl];
}
/**
  */
void RelayOff(uint8_t Rl) {
	Relay_ports[Rl]->BRR = (uint32_t)Relay_pins[Rl];
}
/**
  */
void Init_Button(void) {
 GPIO_InitTypeDef GPIO_InitStructure;

    /* Enable GPIOB clock */
    RCC_APB2PeriphClockCmd(BUTT1_CLK, ENABLE);
    /* Configure the GPIOs */
    GPIO_InitStructure.GPIO_Pin = BUTT1_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(BUTT1_PORT, &GPIO_InitStructure);
    return;
}
/**
  */
void Init_ButtonProc(void) {
 TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
 NVIC_InitTypeDef NVIC_InitStructure;

 	 RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
 	 /* Time base configuration */
 	 TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
 	 TIM_TimeBaseStructure.TIM_Period        = (uint16_t) (SystemCoreClock / ButtonTimPeriod) - 1;
 	 TIM_TimeBaseStructure.TIM_Prescaler     = (ButtonTimPeriod/10) - 1;
 	 TIM_TimeBaseStructure.TIM_ClockDivision = 0;
 	 TIM_TimeBaseStructure.TIM_CounterMode   = TIM_CounterMode_Up;
 	 TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);
 	 /* Enable the TIM4 gloabal Interrupt */
 	 NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;
 	 NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 7;
 	 NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
 	 NVIC_Init(&NVIC_InitStructure);
 	 /* TIM Interrupts enable */
 	 TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
	 TIM_Cmd(TIM4, ENABLE);
 	 return;
}
#ifdef USE_RTC_CLOCK
/**
  * @brief  Configure the RTC peripheral by selecting the clock source.
  * @param  None
  * @retval None
  */
uint8_t RTC_Config(void) {
	/* Enable the PWR clock */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
	/* Дозволити доступ до області резервних даних */
	PWR_BackupAccessCmd(ENABLE);
	/* Якщо годинник вимкнений - ініціалізувати */
	if ((RCC->BDCR & RCC_BDCR_RTCEN) != RCC_BDCR_RTCEN) {
		/* Виконати скидання області резервних даних */
		RCC_BackupResetCmd(ENABLE);
		RCC_BackupResetCmd(DISABLE);
		/* Вибрати джерелом тактових імпульсів зовнішній кварц 32768 і подати тактування */
		RCC_LSEConfig(RCC_LSE_ON);
		while ((RCC->BDCR & RCC_BDCR_LSERDY) != RCC_BDCR_LSERDY) {}
		RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
		RTC_SetPrescaler(0x7FFF); /* Встановити поділювач щоб годинник рахував секунди */
		/* Вмикаємо годинник */
		RCC_RTCCLKCmd(ENABLE);
		/* Wait for RTC APB registers synchronisation */
		RTC_WaitForSynchro();
		return 1;
	}
	return 0;
}

void RTC_GetDateTime(uint32_t RTC_Counter, RTC_DateTime_t* DateTime) {
 unsigned long time;
 unsigned long t1, a, b, c, d, e, m;
 int year = 0;
 int mon = 0;
 int wday = 0;
 int mday = 0;
 int hour = 0;
 int min = 0;
 int sec = 0;
 uint64_t jd = 0;;
 uint64_t jdn = 0;

	jd = ((RTC_Counter+43200)/(86400>>1)) + (2440587<<1) + 1;
	jdn = jd>>1;

	time = RTC_Counter;
	t1 = time/60;
	sec = time - t1*60;

	time = t1;
	t1 = time/60;
	min = time - t1*60;

	time = t1;
	t1 = time/24;
	hour = time - t1*24;

	wday = jdn%7;

	a = jdn + 32044;
	b = (4*a+3)/146097;
	c = a - (146097*b)/4;
	d = (4*c+3)/1461;
	e = c - (1461*d)/4;
	m = (5*e+2)/153;
	mday = e - (153*m+2)/5 + 1;
	mon = m + 3 - 12*(m/10);
	year = 100*b + d - 4800 + (m/10);

	DateTime->Year = year - 2000;
	DateTime->Month = mon;
	DateTime->Date = mday;
	DateTime->Hours = hour;
	DateTime->Minutes = min;
	DateTime->Seconds = sec;
	DateTime->WeekDay = wday;
}
/* Convert Date to Counter */
uint32_t RTC_GetMyCounter(RTC_DateTime_t* DateTime) {
 uint8_t a;
 uint16_t y;
 uint8_t m;
 uint32_t JDN;

	a = (14-DateTime->Month)/12;
	y = DateTime->Year+4800-a+2000;
	m = DateTime->Month+(12*a)-3;

	JDN = DateTime->Date;
	JDN += (153*m+2)/5;
	JDN += 365*y;
	JDN += y/4;
	JDN += -y/100;
	JDN += y/400;
	JDN = JDN -32045;
	JDN = JDN - JULIAN_DATE_BASE;
	JDN *= 86400;
	JDN += (DateTime->Hours*3600);
	JDN += (DateTime->Minutes*60);
	JDN += (DateTime->Seconds);
	return JDN;
}
#endif
/************************ END OF FILE****/
