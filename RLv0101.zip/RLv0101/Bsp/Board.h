/**
  ******************************************************************************
  * @file    stm32f429i_discovery.h
  * @author  MCD Application Team
  * @version V2.1.1
  * @date    10-December-2014
  * @brief   This file contains definitions for STM32F429I-Discovery Kit LEDs,
  *          push-buttons hardware resources.
  ******************************************************************************
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BOARD_H
#define __BOARD_H

#ifdef __cplusplus
 extern "C" {
#endif
                                              
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"

#define ButtonTimPeriod	50000

#define USE_RTC_CLOCK

/**
  * @}
  */ 
#define RED_PIN  					GPIO_Pin_8
#define RED_PORT					GPIOB
#define RED_CLK						RCC_APB2Periph_GPIOB
#define RED_ON						RED_PORT->BSRR = (uint32_t)RED_PIN
#define RED_OFF						RED_PORT->BRR = (uint32_t)RED_PIN
#define GREEN_PIN  					GPIO_Pin_9
#define GREEN_PORT					GPIOB
#define GREEN_CLK					RCC_APB2Periph_GPIOB
#define GREEN_ON					GREEN_PORT->BSRR = 	(uint32_t)GREEN_PIN
#define GREEN_OFF					GREEN_PORT->BRR = (uint32_t)GREEN_PIN

#define POWER_PIN  					GPIO_Pin_8
#define POWER_PORT   				GPIOA
#define INP_ON_PIN  				GPIO_Pin_1
#define INP_ON_PORT  				GPIOA
#define INP_ON_HIGH					INP_ON_PORT->BSRR = (uint32_t)INP_ON_PIN
#define INP_ON_LOW					INP_ON_PORT->BRR = (uint32_t)INP_ON_PIN
#define BUTT1_PIN  					GPIO_Pin_13
#define BUTT1_PORT					GPIOC
#define BUTT1_CLK					RCC_APB2Periph_GPIOC
#define EXT_RESET_PIN  				GPIO_Pin_12
#define EXT_RESET_PORT  			GPIOB
#define EXT_RESETN_CLK				RCC_APB2Periph_GPIOB
#define EXT_RESET_ON				EXT_RESET_PORT->BSRR = (uint32_t)EXT_RESET_PIN;
#define EXT_RESET_OFF				EXT_RESET_PORT->BRR = (uint32_t)EXT_RESET_PIN;
#define AMP_ON_PIN 					GPIO_Pin_13
#define AMP_ON_PORT  				GPIOB
#define AMP_ON_CLK					RCC_APB2Periph_GPIOB
#define M_S_PIN  					GPIO_Pin_14
#define M_S_PORT					GPIOB
#define M_S_CLK						RCC_APB2Periph_GPIOB
#define CAN_S_PIN  					GPIO_Pin_15
#define CAN_S_PORT  				GPIOB
#define CAN_S_CLK					RCC_APB2Periph_GPIOB
#define CAN_S_ON					CAN_S_PORT->BSRR = (uint32_t)CAN_S_PIN;
#define CAN_S_OFF					CAN_S_PORT->BRR = (uint32_t)CAN_S_PIN;
/*############################### SPIx #######################################*/
/**
 * Definition for SPIx EEPROM
 */
#define EEPROM_SPI                  SPI1
#define EEPROM_SPI_CLK              RCC_APB2Periph_SPI1
#define EEPROM_SPI_CLK_INIT         RCC_APB2PeriphClockCmd

#define EEPROM_SPI_SCK_PIN          GPIO_Pin_5
#define EEPROM_SPI_SCK_PORT         GPIOA
#define EEPROM_SPI_SCK_GPIO_CLK     RCC_APB2Periph_GPIOA
#define EEPROM_SPI_SCK_SOURCE       GPIO_PinSource5

#define EEPROM_SPI_MISO_PIN         GPIO_Pin_6
#define EEPROM_SPI_MISO_PORT        GPIOA
#define EEPROM_SPI_MISO_GPIO_CLK    RCC_APB2Periph_GPIOA
#define EEPROM_SPI_MISO_SOURCE      GPIO_PinSource6

#define EEPROM_SPI_MOSI_PIN         GPIO_Pin_7
#define EEPROM_SPI_MOSI_PORT        GPIOA
#define EEPROM_SPI_MOSI_GPIO_CLK    RCC_APB2Periph_GPIOA
#define EEPROM_SPI_MOSI_SOURCE      GPIO_PinSource7

#define EEPROM_SPI_CS_PIN  			GPIO_Pin_4
#define EEPROM_SPI_CS_PORT			GPIOA
#define EEPROM_SPI_CS_GPIO_CLK		RCC_APB2Periph_GPIOA
#define EEPROM_SPI_CS_HIGH			EEPROM_SPI_CS_PORT->BSRR = (uint32_t)EEPROM_SPI_CS_PIN
#define EEPROM_SPI_CS_LOW			EEPROM_SPI_CS_PORT->BRR = (uint32_t)EEPROM_SPI_CS_PIN
/*############################### RS485 - 1 ##################################*/
#define RS485						USART1

#define RS485_DE_PIN  				GPIO_Pin_15
#define RS485_DE_PORT     			GPIOA
#define RS485_DE_HIGH				RS485_DE_PORT->BSRR = (uint32_t)RS485_DE_PIN
#define RS485_DE_LOW				RS485_DE_PORT->BRR = (uint32_t)RS485_DE_PIN
 /* Definition for USARTx's NVIC */
 #define RS485_IRQn      			USART1_IRQn
 #define RS485_IRQHandler 			USART1_IRQHandler
/*############################### RS485 - 2 ##################################*/
#define RS232				USART2
#define RS232_CLK_ENABLE			RCC_APB1Periph_USART2
#define RS232_RX_GPIO_CLK_ENABLE   	RCC_APB2Periph_GPIOA
#define RS232_TX_GPIO_CLK_ENABLE    RCC_APB2Periph_GPIOA

/* Definition for USARTx Pins */
#define RS232_TX_PIN             	GPIO_Pin_2
#define RS232_TX_PORT            	GPIOA
#define RS232_RX_PIN                GPIO_Pin_3
#define RS232_RX_PORT            	GPIOA
 /* Definition for USARTx's NVIC */
#define RS232_IRQn 					USART2_IRQn
#define RS232_IRQHandler 			USART2_IRQHandler
 /*########################### LCD hd44780 ##################################*/
#define RELAY1_PIN            		GPIO_Pin_0
#define RELAY1_PORT       			GPIOB
#define RELAY1_CLK_ENABLE   		RCC_APB2Periph_GPIOB
#define RELAY2_PIN            		GPIO_Pin_1
#define RELAY2_PORT       			GPIOB
#define RELAY2_CLK_ENABLE   		RCC_APB2Periph_GPIOB
#define RELAY3_PIN            		GPIO_Pin_2
#define RELAY3_PORT       			GPIOB
#define RELAY3_CLK_ENABLE   		RCC_APB2Periph_GPIOB
#define RELAY4_PIN            		GPIO_Pin_3
#define RELAY4_PORT       			GPIOB
#define RELAY4_CLK_ENABLE   		RCC_APB2Periph_GPIOB
#define RELAY5_PIN            		GPIO_Pin_4
#define RELAY5_PORT       			GPIOB
#define RELAY5_CLK_ENABLE   		RCC_APB2Periph_GPIOB
#define RELAY6_PIN            		GPIO_Pin_5
#define RELAY6_PORT       			GPIOB
#define RELAY6_CLK_ENABLE   		RCC_APB2Periph_GPIOB
#define RELAY7_PIN            		GPIO_Pin_6
#define RELAY7_PORT       			GPIOB
#define RELAY7_CLK_ENABLE   		RCC_APB2Periph_GPIOB
#define RELAY8_PIN            		GPIO_Pin_7
#define RELAY8_PORT       			GPIOB
#define RELAY8_CLK_ENABLE   		RCC_APB2Periph_GPIOB

#define JULIAN_DATE_BASE	2440588

typedef struct {
	uint8_t Hours;
	uint8_t Minutes;
	uint8_t Seconds;
	uint8_t Date;
	uint8_t WeekDay;
	uint8_t Month;
	uint8_t Year;
} RTC_DateTime_t;

void MainPWR_Init(void);
void DMA_ADC_Configuration(void);

#ifdef __cplusplus
}
#endif

#endif /* __BOARD_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
