/**
  ******************************************************************************
  * @file    main.h
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    31-October-2017
  * @brief   This file contains all the functions prototypes for the main.c 
  *          file.
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <string.h>
#include "Board.h"
#include "EEPROM_Base.h"
#include "user_mb_app.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
//#define DEBUG_PLC

#define MB_VERSION_MAJOR  	2
#define MB_VERSION_MINOR 	1
#define VERSION_MAJOR     	1
#define VERSION_MINOR     	0
#define VERSION_REVISION  	17

#define TYPE_OF_UNIT  		(uint8_t)((MB_VERSION_MINOR<<4)|MB_VERSION_MAJOR)

#define NMB_UNIT			8
#define NMB_RELAYS			8

#define COIL_MODE			0
#define COIL_S_MODE			1
#define PSW_MODE			2
#define CMD_MODE			3
#define BUFF_MODE			4
#define REG_MODE			5

#define READ_PCB_CMD		0
#define WRITE_PCB_CMD		1

#define GET_SYSTEM_TIME		22
#define SET_SYSTEM_TIME		23

#define GET_VERSION			28

#define GET_RTU_UNIT_CONF	48
#define SET_RTU_UNIT_CONF	49

#define GET_PCB_CONF		51
#define SET_PCB_CONF		52
#define SAVE_PCB_CONF		53
#define INT_PLC_INP_GET		54
#define INT_PLC_OUT_SET		55

 /*--------------- Tasks Priority -------------*/
#define PX1N_PROC_TASK_PRIO 	(tskIDLE_PRIORITY + 4)
#define MB_COMMAND_PRIO	  		(tskIDLE_PRIORITY + 4)
#define I2C_TASK_PRIO	  		(tskIDLE_PRIORITY + 6)
#define MODBUS_SLAVE_PULL  		(tskIDLE_PRIORITY + 7)
//#define MAIN_TASK_DELAY			300
 /* ----------------------- Type definitions ---------------------------------*/
 typedef uint8_t err_t;
  /* Definitions for error constants. */
 #define ERR_OK          0    /* No error, everything OK. */
 #define ERR_MEM        -1    /* Out of memory error.     */
 #define ERR_BUF        -2    /* Buffer error.            */
 #define ERR_TIMEOUT    -3    /* Timeout.                 */
 #define ERR_RTE        -4    /* Routing problem.         */
 #define ERR_INPROGRESS -5    /* Operation in progress    */
 #define ERR_VAL        -6    /* Illegal value.           */
 #define ERR_WOULDBLOCK -7    /* Operation would block.   */
 #define ERR_USE        -8    /* Address in use.          */
 #define ERR_ISCONN     -9    /* Already connected.       */

 #define ERR_IS_FATAL(e) ((e) < ERR_ISCONN)

 #define ERR_ABRT       -10   /* Connection aborted.      */
 #define ERR_RST        -11   /* Connection reset.        */
 #define ERR_CLSD       -12   /* Connection closed.       */
 #define ERR_CONN       -13   /* Not connected.           */
 #define ERR_ARG        -14   /* Illegal argument.        */
 #define ERR_IF         -15   /* Low-level netif error    */

typedef union {
  uint8_t d8;
  struct {
	  uint8_t Reserv	: 6;
	  uint8_t Ready		: 1;
	  uint8_t Write		: 1;
  } b;
} SlaveState_t;

typedef union {
  uint32_t d32;
  struct {
	  uint32_t Reserv	: 12;
	  uint32_t PlcComm	: 8;
	  uint32_t NmbPCB	: 3;
	  uint32_t Command	: 8;
	  uint32_t SetCmd	: 1;
  } dw;
} MBComm_t;

typedef struct {
	uint8_t InpAddr;
	uint8_t OutpAddr;
	PCB_Conf_t Conf;
} PcbUnit_t;

#define BUTT_PLC_RUN_STOP		2
#define BUTT_RESET				30

typedef union {
  uint32_t d32;
  struct {
	  uint32_t Reserve			: 12;
	  uint32_t CntBtn1			: 8;
	  uint32_t CntBtn2			: 8;
	  uint32_t PressdBtn1		: 1;
	  uint32_t PressdBtn2		: 1;
	  uint32_t BtnReset			: 1;
	  uint32_t BtnStopPLC		: 1;
  } dw;
} ButtonPSW_t;
/* Exported macro ------------------------------------------------------------*/
#define min(x, y) (((x) < (y)) ? (x) : (y))
/* Exported functions ------------------------------------------------------- */
//void ResetInit(void);
//void EXTILine10_15_Config(void);
//void EXTI_PowerPin_Config(void);
uint16_t CRC16(uint8_t *data, uint16_t bytes);
uint8_t CRC8(uint8_t *data, uint16_t bytes);

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */


/************************ END OF FILE ****/

