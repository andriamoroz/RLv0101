#include "stm32f10x_rtc.h"
#include "main.h"
#include "mb.h"
#include "user_mb_app.h"
#include "system.h"
#include "EEPROM_Base.h"

//bit  RUN = 0;
const uint16_t FwVersion[3] = {VERSION_MAJOR, VERSION_MINOR, VERSION_REVISION};
extern FunkList key_list[16];
extern u8 PlcRxPtr;
extern volatile u8 ProgWriteBuffer[FLASH_SECTOR_SIZE];
extern USHORT usSRegHoldBuf[S_REG_HOLDING_NREGS_BUFF_BUFF];
extern volatile unsigned int PS_BIT;
extern volatile unsigned int PS1_BIT;
extern PcbUnit_t PCB_Conf[NMB_UNIT];
extern PCB_Wrk_t PCB_Wrk;
extern TYPE_BIT_BYTE rX[_X_BYTE];
extern TYPE_BIT_BYTE *ErrX;
void I2C2_init(void);
void InitUnit(void);
void Init_Button(void);
void Init_ButtonProc(void);
void Init_RelayPin(void);
void Init_ExtResetPin(void);
void MainPWR_Init(void);
void InpOn_Init(void);
void AmpOn_Init(void);
void Master_Init(void);
uint8_t xPortSerialInit(uint32_t ulBaudRate, uint8_t ucDataBits, eMBParity eParity, uint8_t ucStopBits);
void FX1N_Processing(void *pvParameters);
static void ModbusSlavePoll(void* pvParameters);
void MbComm_thread(void *pvParameters);
void CODE_scan(void);
void RTC_GetDateTime(uint32_t RTC_Counter, RTC_DateTime_t* DateTime);
void Led_Init(void);

__attribute__((weak)) void _close(void){}
__attribute__((weak)) void _lseek(void){}
__attribute__((weak)) void _read(void){}
__attribute__((weak)) void _write(void){}
__attribute__((weak)) void _fstat(void){}
__attribute__((weak)) void _getpid(void){}
__attribute__((weak)) void _gettimeofday(void){}
__attribute__((weak)) void _isatty(void){}
__attribute__((weak)) void _kill(void){}
/* Private variables ---------------------------------------------------------*/
osThreadId InitThreadHandle;
/* Private function prototypes -----------------------------------------------*/
static void sInitThread(void * pvParameters);


unsigned int TYPE_BCD[16] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,
                             0x80,0x90,0x88,0x83,0xc6,0xa1,0x86,0x8e};
/***************************************************************************************/

osSemaphoreId PLC_Semph = NULL;
osSemaphoreId CommRcv_Sem = NULL;

volatile PSW_t PSW;
volatile SysPSW_t *SysPSW;
volatile UnitSeting_t UnitSeting;
volatile UnitSeting_t *pUnitSeting;
volatile PcbSeting_t PcbSeting;
volatile PcbSeting_t *pPcbSeting;
volatile MBComm_t *pMBComm;
volatile ButtonPSW_t ButtonPSW;
RTC_DateTime_t DateTime;

/*
 * @brief  Calculate CRC16.
 * @param  data: buffer address.
 * @param  bytes: number bytes in buffer.
 * @retval CRC16
 */
uint16_t CRC16(uint8_t *data, uint16_t bytes) {
 uint16_t crc = 0;
 uint8_t i, c, n;

 	 while(bytes--)
 	 {
 		 c = *data++;
 		 for (i = 0; i < 8; i++)
 		 {
 			 n = crc >> 8;
 			 crc <<= 1;
 			 if ((n ^ c) & 0x80) {
 				 crc ^= 0x1021;
 			 }
 			 c <<= 1;
 		 }
 	 }
 	 return crc;
}
/*
 * @brief  Calculate CRC8.
 * @param  data: buffer address.
 * @param  bytes: number bytes in buffer.
 * @retval CRC8
 */
uint8_t CRC8(uint8_t *data, uint16_t bytes) {
 uint8_t crc = 0;
 uint8_t i, c;

	 while(bytes--)
	 {
 		 c = *data++;
		 crc = crc ^ c;
		 for (i = 0; i < 8; i++)
		 {
			 if (crc & 0x01) {
				 crc = (crc >> 1) ^ 0x8C;
			 } else {
				 crc >>= 1;
			 }
		 }
 	 }
 	 return crc;
}
/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int main(void) {
 RCC_ClocksTypeDef RCC_Clocks;

	SystemInit();
	RCC_GetClocksFreq(&RCC_Clocks);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
    osThreadDef(InitThread, sInitThread, osPriorityNormal, 0, configMINIMAL_STACK_SIZE * 3);
    InitThreadHandle = osThreadCreate(osThread(InitThread), NULL);

    osKernelStart();

    /* We should never get here as control is now taken by the scheduler */
    for(;;){}
}

static void sInitThread(void * pvParameters) {
 u32 var1;
 u32 var2;
 uint16_t i;
 eMBErrorCode eStatus;
 uint16_t wCRC;

	SysPSW = (SysPSW_t*)&usSRegHoldBuf[S_REG_HOLDING_START_PSW_BUFF];
	pUnitSeting = (UnitSeting_t*)&usSRegHoldBuf[S_REG_HOLDING_START_BUFF_BUFF];
	pPcbSeting = (PcbSeting_t*)&usSRegHoldBuf[S_REG_HOLDING_START_BUFF_BUFF];
	pMBComm = (MBComm_t*)&usSRegHoldBuf[S_REG_HOLDING_START_COMM_BUFF];
	pMBComm->d32 = 0;
 	PSW.d16 = 0;
 	SysPSW->d16 = 0;
 	ErrX = &rX[(_X_BYTE / 2)];
 	osSemaphoreDef(PLC_Sem);
    PLC_Semph = osSemaphoreCreate(osSemaphore(PLC_Sem), 1);
	osSemaphoreDef(CommRcv_Sem);
	CommRcv_Sem = osSemaphoreCreate(osSemaphore(CommRcv_Sem), 1);
    Init_ExtResetPin();
    EXT_RESET_ON;
    MainPWR_Init();
 	InpOn_Init();
 	AmpOn_Init();
 	Led_Init();
 	Init_RelayPin();
 	RED_ON;
 	GREEN_OFF;
    FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);
    FLASH_SetLatency(FLASH_Latency_2);
    INP_ON_HIGH;
	vTaskDelay(200);
	EXT_RESET_OFF;
	vTaskDelay(800);
//vTaskDelete(NULL); /************************************************************************************************/
    Master_Init();
    Init_Button();
//	sEEPROM_Init();
//	sEEPROM_ReadBuffer((uint8_t*)&UnitSeting, OFFSET_UNITSETING, sizeof(UnitSeting_t));
	wCRC = CRC16((uint8_t*)&UnitSeting, sizeof(UnitSeting_t)-2);
	if ((wCRC != UnitSeting.wCRC) || (wCRC == 0xffff) ||
		(GPIO_ReadInputDataBit(BUTT1_PORT, BUTT1_PIN) == Bit_RESET)) {
		UnitSeting.SlavePort.Address = 2;
		UnitSeting.SlavePort.ulBaudRate = 9600;
		UnitSeting.SlavePort.ucDataBits = 8;
		UnitSeting.SlavePort.eParity = MB_PAR_NONE;
		UnitSeting.SlavePort.Config.b.StopBits = 0;
		UnitSeting.StartAddr = 0;
		UnitSeting.Conf.b.ConnPCB = 2;
		UnitSeting.wCRC = CRC16((uint8_t*)&UnitSeting, sizeof(UnitSeting_t)-2);
//		sEEPROM_WriteBuffer((uint8_t*)&UnitSeting, OFFSET_UNITSETING, sizeof(UnitSeting_t));
	}
	memcpy((void*)pUnitSeting, (void*)&UnitSeting, sizeof(UnitSeting_t));
	Init_ButtonProc();
	vTaskDelay(100);
	I2C2_init();
 	xPortSerialInit(19200, 8, MB_PAR_NONE, 0);
	if (SysPSW->w.MasterMode) {
		eStatus = eMBInit(MB_RTU, UnitSeting.SlavePort.Address, UnitSeting.SlavePort.ulBaudRate,
				UnitSeting.SlavePort.ucDataBits, UnitSeting.SlavePort.eParity, UnitSeting.SlavePort.Config.b.StopBits);
		eStatus = eMBEnable();
	}
	osSemaphoreWait(CommRcv_Sem, 1);
	osSemaphoreWait(PLC_Semph, 1);
	if (SysPSW->w.MasterMode) {
		vTaskDelay(5000);
	}
	InitUnit();
	if (SysPSW->w.MasterMode) {
		xTaskCreate(MbComm_thread, (const char*)"MB_COMM", configMINIMAL_STACK_SIZE * 2, NULL, MB_COMMAND_PRIO, NULL);
		xTaskCreate(ModbusSlavePoll, (const char*)"SLAVE_PULL", configMINIMAL_STACK_SIZE * 2, NULL, MODBUS_SLAVE_PULL, NULL);
	}
 	RED_OFF;
 	GREEN_ON;
	vTaskDelete(NULL);
}
/**
  * @brief  Modbus_Process_Handle
  * @param  None
  * @retval None
  */
static void ModbusSlavePoll(void* pvParameters) {
	while(1)
	{
		eMBPoll();
	}
}
//-------- main  END ----------//

